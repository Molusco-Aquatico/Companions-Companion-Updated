

function CC_CompanionRapportGood_Keyboard_OnInitialize(control)

end